import random


directory = "c:/Users/disto/OneDrive/Documents/MultiMC/instances/Fabulously Optimized 5.1.0/.minecraft/saves/project fw/datapacks/FW Datapack/data/weapons/functions/generic/fire/spread/"

filename = "01.mcfunction"
full_directory = directory+filename
spread = open(full_directory,'w')

x = [-0.75,0.75]
y = [-0.5,0.5]

data = "execute store result score @s fwg.rng run loot spawn ~ ~-10 ~ loot weapons:spread\n"
spread.write(data)
for i in range(1,13):
    data = "execute if score @s fwg.rng matches "+str(i)+" as @s anchored eyes rotated ~"+str(round(random.uniform(x[0], x[1]), 2))+" ~"+str(round(random.uniform(y[0],y[1]), 2))+" run function raycast:bullets/start\n"
    spread.write(data)
spread.close()